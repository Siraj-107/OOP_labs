class Animal 
 {
   String name ;
   int   age ;
   public Animal (String name , int age )  
{
   this.name = name ;
   this.age = age ;
}   
void Set_name (String name ){
this.name = name ;
}  
String Get_name (){
  return name ;
} 
void Set_age () 

  public void Dis() 
{
  System.out.println("Name " + name +"\n Age"+age );
 }

 }

class Dog extends Animal 
{
   public dog (String name , int age  ) 
{
   super(name , age) ;
} 
    public void Dis() 
{
   System.out.println("Name " + name +"\n Age"+age );
}



} 
 



class Cat extends Animal 
 {
   public dog (String name , int age  ) 
 {
   super(name , age) ;
 } 
   
    public void Dis() 
{
 System.out.println("Name " + name +"\n Age"+age );
 }
 }   

class Animals {
public static void main (string [] args ) {
Animal a = new Animal("abc " ,123);
Dog    d = new Dog ("xyz",231) ;
Cat    c  = new Cat ("sss" , 123) ;

a.Dis();
d.Dis();
c.Dis();
} 
} 




