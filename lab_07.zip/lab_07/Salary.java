class Empolyee {
double salary ; 
public Empolyee(double salary ) {
this.salary =  salary ;
                              } 
void Set_Empolyee(double salary ){
this.salary = salary ;          }   
   
double Get_salary () {
   return salary ;
   } 

                                 
double Calculate_salary (){
   return salary ;
                          } 
       } 

class Manager extends Empolyee { 
double m_salary ;
 public Manager(double salary , double m_salary) {
          super(salary);
        this.m_salary = m_salary ;
                                                } 
void Set_Manager(double m_salary){
   this.m_salary = m_salary ;   
                                 }  

 double Get_m_salary(){
  return m_salary ;   } 

  double Calculate_salary (){
   return super.salary + m_salary ; 

                           }  

       }  
class Worker extends Empolyee { 
double w_salary ; 

 public Worker(double salary  , double w_salary) {
          super(salary );
        this.w_salary = w_salary ; 
       
      } 
void Set_Worker(double w_salary){
   this.w_salary = w_salary ;   
                                 }  

 double Get_w_salary(){
  return w_salary ;  } 

  double Calculate_salary(){
   return salary+w_salary ; 

                         } 
       } 
class Salary {
public static void main (String [] argu ) {
Empolyee  e =  new Empolyee (400); 
 Manager  m =  new  Manager (e.Get_salary() , 400);
 Worker  w =  new  Worker (300 ,1000  ); 
e.Set_Empolyee(400);
System.out.println("Empolyee "+e.Calculate_salary ());  
m.Set_Manager(500);
System.out.println("Manager"+m.Calculate_salary ());
System.out.println("Worker "+w.Calculate_salary ());
 } 
 }







 