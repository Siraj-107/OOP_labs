/* 
class Message {
String text ; 
public Message (String  text){
this.text = text ;
}
public void Dis( ){
System.out.println("Text :"+text ) ;
}  
} 
class SMS extends Message {
String contact_no ;
 public SMS(String text , String contact_no ){
 super(text); 
 this.contact_no = contact_no ;
 }  
public void Dis( ){
System.out.println("Text :"+super.text + "\n" +"Contact"+contact_no) ;
}   
} 
class Email extends Message {
String sender ;
String reciever ;
String subject ;
public Email( String text  , String sender , String reciever , String subject ) {
 super (text ) ;
 this.sender = sender ;
 this.reciever = reciever ;
 this.subject =  subject ;  
 } 
 public void Dis( ){
System.out.println("Text :"+super.text + "\n"+"Sender:"+sender+"\n"+"Reciever:"+reciever+"\n"+"Subject:"+subject ) ;
}
} 
class Abc {
public static void main (String []  args ) {
Message m = new Message ("hello " );
SMS     s = new SMS ("XYZ " , "o342" ) ;
Email   e = new Email ("siraj " , "abc" ," java programing " , "ggg" );
m.Dis();
s.Dis();
e.Dis();
} 
}  
*/ 


 class Message {
 String text ;
 public Message (String text ) {
 this.text = text ;
}  
  public void Set(String text ){
 this.text = text ;
} 
  String get( ) {
  return text ; 
}
  String  tostring(){
 return text ; 
}  

       } 
 class SMS extends Message {
 String contact ;
 public SMS (String text , String contact ){
  super(text ) ;
  this.contact = contact ;
} 
 public void Set_contact (String contact ) {
 this.contact = contact  ; 
}  
  String get_contact (){
  return contact ; 
}
  String tostring () {
  return "Text:"+text+"\n contact"+contact ; 
}  

       } 
class Email extends Message {
 String sender ;
 String reciever ;
 String subject ;
 public Email ( String text ,  String sender ,String reciever , String subject ) {
 super (text ) ;
 this.sender = sender ;
 this.reciever = reciever ;
 this.subject = subject ;
}
 public void set_sender(String sender){
 this.sender = sender ;
} 
 public void set_reciever(String reciever){
 this. reciever =  reciever ;
}  
  public void set_subjectr(String subject){
 this. subject =  subject ;
}  
  String get_sender(){
 return sender ;
} 
  String get_reciever(){
 return reciever ;
} 
  String get_subject(){
 return subject;
}
   String tostring () {
          return "Text: " + text + "\nSender: " + sender + "\nReceiver: " + reciever + "\nSubject: " + subject;
}   
    }  
class Abc {
public static void main (String [] argu ) {
Message m = new Message ("abc" );
SMS    s  = new SMS ("hello" , "123" ) ;
Email e   = new Email ("abc " , "hello " , "world " , "java " ) ;
 System.out.println(m.tostring()); 
  System.out.println(s.tostring());
   System.out.println(e.tostring());
} 
} 

 

 




























