class   BankAccount {
    double getInterestRate(){
      return 0.5 ; 
 }
 } 
class  SavingsAccount extends BankAccount {
   double getInterestRate(){
      return 0.10 ; 
}  
}
public class Intrest {
    public static void main(String[] args) {
        BankAccount general = new BankAccount();
        SavingsAccount savings = new SavingsAccount();

        System.out.println("BankAccount Interest Rate: " + general.getInterestRate());
        System.out.println("SavingsAccount Interest Rate: " + savings.getInterestRate());
    }
}