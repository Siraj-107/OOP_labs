/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package task_1;

/**
 *
 * @author f24ari107
 */
public class Cat extends Dog {
    public void makesound(){
        System.out.println("meo");
    }
    
}
