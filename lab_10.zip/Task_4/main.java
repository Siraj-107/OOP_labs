/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_4;

/**
 *
 * @author f24ari107
 */
 class main { 
     public static void main (String [] args){
         duck d = new duck();
         d.fly();
         d.swim();
     }
    
}
