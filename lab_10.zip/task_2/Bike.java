/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package task_2;

/**
 *
 * @author f24ari107
 */
public class Bike {
        public void start(){
        System.out.println("Bike  start");
    } 
    public void stop(){
        System.out.println("bike  stop at near aror city");
    }
    
}

