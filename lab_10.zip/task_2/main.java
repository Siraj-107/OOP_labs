/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package task_2;

/**
 *
 * @author f24ari107
 */
 class main { 
     public static void main (String [] argu ){
         Car c = new Car ();
         Bike d = new Bike ();
         c.start();
         c.stop();
         d.start();
         d.stop();
     }
    
}
