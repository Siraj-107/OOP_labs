/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package task_3;

/**
 *
 * @author f24ari107
 */
 class Abc {  
     public static void main (String [] argu){
     Rectangle r = new Rectangle(10.3 , 20.3);
     r.area();
     r.print();
    
 
 }  
 } 
